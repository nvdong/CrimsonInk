<header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
	<p class="main-title bhf-hidden" itemprop="headline">
		<a href="{{ route('page.home') }}" title="Crimson Ink" rel="home">Crimson Ink</a>
	</p>
	<style>
		.elementor-10 .elementor-element.elementor-element-a32d64e {
			z-index: 999;
		}

		.elementor-10 .elementor-element.elementor-element-7485a56>.elementor-widget-wrap>.elementor-widget:not(.elementor-widget__width-auto):not(.elementor-widget__width-initial):not(:last-child):not(.elementor-absolute) {
			margin-block-end: 0px;
		}

		.elementor-10 .elementor-element.elementor-element-7485a56>.elementor-element-populated {
			margin: 0px 0px 0px 0px;
			--e-column-margin-right: 0px;
			--e-column-margin-left: 0px;
			padding: 0px 0px 0px 0px;
		}

		.elementor-10 .elementor-element.elementor-element-4250412>.elementor-container>.elementor-column>.elementor-widget-wrap {
			align-content: center;
			align-items: center;
		}

		.elementor-10 .elementor-element.elementor-element-4250412 {
			padding: 10px 10px 10px 10px;
		}

		.elementor-10 .elementor-element.elementor-element-1a7e805>.elementor-widget-wrap>.elementor-widget:not(.elementor-widget__width-auto):not(.elementor-widget__width-initial):not(:last-child):not(.elementor-absolute) {
			margin-block-end: 0px;
		}

		.elementor-10 .elementor-element.elementor-element-1a7e805>.elementor-element-populated {
			padding: 0px 15px 0px 15px;
		}

		.elementor-widget-image .widget-image-caption {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-10 .elementor-element.elementor-element-827a31b {
			width: auto;
			max-width: auto;
			text-align: start;
		}

		.elementor-10 .elementor-element.elementor-element-827a31b img {
			width: 120px;
		}

		.elementor-10 .elementor-element.elementor-element-58ddeb8.elementor-column>.elementor-widget-wrap {
			justify-content: flex-end;
		}

		.elementor-10 .elementor-element.elementor-element-58ddeb8>.elementor-widget-wrap>.elementor-widget:not(.elementor-widget__width-auto):not(.elementor-widget__width-initial):not(:last-child):not(.elementor-absolute) {
			margin-block-end: 0px;
		}

		.elementor-10 .elementor-element.elementor-element-58ddeb8>.elementor-element-populated {
			padding: 0px 15px 0px 0px;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a {
			background-color: var(--e-global-color-182e802);
			font-family: "Work Sans", Sans-serif;
			letter-spacing: 0.5px;
			padding: 10px 10px 10px 10px;
			color: var(--e-global-color-39cd785);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a:hover,
		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a:focus,
		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a:active,
		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li:hover>a {
			background-color: #202020;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li.>a {
			background-color: #202020;
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel {
			background-color: #202020;
			border-style: none;
			border-radius: 0px 0px 0px 0px;
			min-width: 180px;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger:hover {
			background-color: #10101000;
			border-style: none;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-menu-container {
			height: 40px;
			border-radius: 0px 0px 0px 0px;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a {
			font-family: "Work Sans", Sans-serif;
			font-size: 15px;
			font-weight: 400;
			text-transform: uppercase;
			letter-spacing: 1px;
			color: var(--e-global-color-39cd785);
			padding: 0px 15px 0px 15px;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a:hover {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a:focus {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a:active {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li:hover>a {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li:hover>a .elementskit-submenu-indicator {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a:hover .elementskit-submenu-indicator {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a:focus .elementskit-submenu-indicator {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a:active .elementskit-submenu-indicator {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li.>a {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li.>a {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li.>a .elementskit-submenu-indicator {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a:hover {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a:focus {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a:active {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li:hover>a {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-submenu-panel {
			padding: 1px 1px 1px 1px;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger {
			float: right;
			width: 0px;
			border-style: none;
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger>.ekit-menu-icon {
			font-size: 0px;
			color: var(--e-global-color-39cd785);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger .elementskit-menu-hamburger-icon {
			background-color: var(--e-global-color-39cd785);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger:hover .elementskit-menu-hamburger-icon {
			background-color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger:hover>.ekit-menu-icon {
			color: var(--e-global-color-accent);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-close {
			color: rgba(51, 51, 51, 1);
		}

		.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-close:hover {
			color: rgba(0, 0, 0, 0.5);
		}

		@media(max-width:1024px) {
			.elementor-10 .elementor-element.elementor-element-4250412 {
				padding: 12px 0px 12px 0px;
			}

			.elementor-10 .elementor-element.elementor-element-827a31b img {
				width: 150px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-nav-identity-panel {
				padding: 10px 0px 10px 0px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-menu-container {
				max-width: 350px;
				border-radius: 0px 0px 0px 0px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav>li>a {
				color: #000000;
				padding: 10px 15px 10px 15px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel>li>a {
				padding: 15px 15px 15px 15px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-navbar-nav .elementskit-submenu-panel {
				border-radius: 0px 0px 0px 0px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger {
				padding: 0px 0px 0px 0px;
				width: 45px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger>.ekit-menu-icon {
				font-size: 32px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-close {
				padding: 8px 8px 8px 8px;
				margin: 12px 12px 12px 12px;
				width: 45px;
				border-radius: 3px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-nav-logo>img {
				max-width: 160px;
				max-height: 60px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-nav-logo {
				margin: 5px 0px 5px 0px;
				padding: 5px 5px 5px 5px;
			}
		}

		@media(max-width:767px) {
			.elementor-10 .elementor-element.elementor-element-1a7e805 {
				width: 50%;
			}

			.elementor-10 .elementor-element.elementor-element-827a31b img {
				width: 80px;
			}

			.elementor-10 .elementor-element.elementor-element-58ddeb8 {
				width: 50%;
			}

			.elementor-10 .elementor-element.elementor-element-58ddeb8>.elementor-element-populated {
				padding: 0px 30px 0px 15px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 button.elementskit-menu-hamburger>.ekit-menu-icon {
				font-size: 32px;
			}

			.elementor-10 .elementor-element.elementor-element-6c16739 .elementskit-nav-logo>img {
				max-width: 120px;
				max-height: 80px;
			}
		}

		@media(min-width:768px) {
			.elementor-10 .elementor-element.elementor-element-7485a56 {
				width: 100%;
			}

			.elementor-10 .elementor-element.elementor-element-1a7e805 {
				width: 10%;
			}

			.elementor-10 .elementor-element.elementor-element-58ddeb8 {
				width: 90%;
			}
		}

		@media(max-width:1024px) and (min-width:768px) {
			.elementor-10 .elementor-element.elementor-element-1a7e805 {
				width: 15%;
			}

			.elementor-10 .elementor-element.elementor-element-58ddeb8 {
				width: 85%;
			}
		}
	</style>
	<div data-elementor-type="wp-post" data-elementor-id="10" class="elementor elementor-10">
		<section
			class="elementor-section elementor-top-section elementor-element elementor-element-a32d64e elementor-section-full_width she-header-yes elementor-section-height-default elementor-section-height-default"
			data-id="a32d64e" data-element_type="section" data-e-type="section"
			data-settings="{&quot;transparent&quot;:&quot;yes&quot;,&quot;scroll_distance&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:160,&quot;sizes&quot;:[]},&quot;background_show&quot;:&quot;yes&quot;,&quot;background&quot;:&quot;#000000E6&quot;,&quot;shrink_header_logo&quot;:&quot;yes&quot;,&quot;custom_height_header_logo&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:90,&quot;sizes&quot;:[]},&quot;transparent_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;scroll_distance_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;scroll_distance_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;she_offset_top&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;she_offset_top_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;she_offset_top_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;she_width&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:100,&quot;sizes&quot;:[]},&quot;she_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;she_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;she_padding&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:0,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:0,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;she_padding_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;she_padding_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;custom_height_header_logo_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;custom_height_header_logo_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}">
			<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7485a56"
					data-id="7485a56" data-element_type="column" data-e-type="column">
					<div class="elementor-widget-wrap elementor-element-populated">
						<section
							class="elementor-section elementor-inner-section elementor-element elementor-element-4250412 elementor-section-content-middle elementor-section-full_width elementor-section-height-default elementor-section-height-default"
							data-id="4250412" data-element_type="section" data-e-type="section">
							<div class="elementor-container elementor-column-gap-default">
								<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1a7e805"
									data-id="1a7e805" data-element_type="column" data-e-type="column">
									<div class="elementor-widget-wrap elementor-element-populated">
										<div class="elementor-element elementor-element-827a31b elementor-widget__width-auto elementor-widget elementor-widget-image"
											data-id="827a31b" data-element_type="widget" data-e-type="widget"
											data-widget_type="image.default">
											<div class="elementor-widget-container">
												<a href="{{ route('page.home') }}">
													<img fetchpriority="high" width="512" height="512"
														src="{{ asset('assets/imgs/logo.png') }}"
														class="attachment-full size-full wp-image-12"
														alt="Mr. Dolphin Tattoo Studio"
														srcset="{{ asset('assets/imgs/logo.png') }} 512w, {{ asset('assets/imgs/logo.png') }} 300w, {{ asset('assets/imgs/logo.png') }} 150w"
														sizes="(max-width: 512px) 100vw, 512px" /> 
													</a>
											</div>
										</div>
									</div>
								</div>
								<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-58ddeb8"
									data-id="58ddeb8" data-element_type="column" data-e-type="column">
									<div class="elementor-widget-wrap elementor-element-populated">
										<div class="elementor-element elementor-element-6c16739 elementor-widget elementor-widget-ekit-nav-menu"
											data-id="6c16739" data-element_type="widget" data-e-type="widget"
											data-widget_type="ekit-nav-menu.default">
											<div class="elementor-widget-container">
												<nav class="ekit-wid-con ekit_menu_responsive_tablet"
													data-hamburger-icon="icon icon-menu-7"
													data-hamburger-icon-type="icon" data-responsive-breakpoint="1024"
													data-close-on-anchor="no">
													<button class="elementskit-menu-hamburger elementskit-menu-toggler"
														type="button" aria-expanded="false"
														aria-controls="ekit-megamenu-main-menu" aria-label="Menu">
														<i aria-hidden="true"
															class="ekit-menu-icon icon icon-menu-7"></i> </button>
													<div id="ekit-megamenu-main-menu"
														class="elementskit-menu-container elementskit-menu-offcanvas-elements elementskit-navbar-nav-default ekit-nav-menu-one-page-no ekit-nav-dropdown-hover">
														<ul id="menu-main-menu"
															class="elementskit-navbar-nav elementskit-menu-po-right submenu-click-on-icon">
															<li id="menu-item-594"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-594 nav-item elementskit-mobile-builder-content active{{ request()->routeIs('page.home') ? ' current-menu-item current_page_item active' : '' }}"
																data-vertical-menu=750px><a
																	href="{{ route('page.home') }}"
																	class="ekit-menu-nav-link active{{ request()->routeIs('page.home') ? ' active' : '' }}">Home</a>
															</li>
															<li id="menu-item-607"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-607 nav-item elementskit-dropdown-has relative_position elementskit-dropdown-menu-default_width elementskit-mobile-builder-content{{ request()->routeIs('page.about-us') ? ' current-menu-item current_page_item active' : '' }}"
																data-vertical-menu=750px>
																<a href="{{ route('page.about-us') }}"
																	class="ekit-menu-nav-link ekit-menu-dropdown-toggle{{ request()->routeIs('page.about-us') ? ' active' : '' }}"
																	aria-haspopup="true" aria-expanded="false"
																	aria-controls="ekit-submenu-607">About Us</a>
																
															</li>
															<li id="menu-item-823"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-823 nav-item elementskit-dropdown-has relative_position elementskit-dropdown-menu-default_width elementskit-mobile-builder-content{{ request()->routeIs('page.tattoo-styles*') ? ' current-menu-ancestor current-menu-item active' : '' }}"
																data-vertical-menu=750px><a
																	href="{{ route('page.tattoo-styles') }}"
																	class="ekit-menu-nav-link ekit-menu-dropdown-toggle{{ request()->routeIs('page.tattoo-styles*') ? ' active' : '' }}"
																	aria-haspopup="true" aria-expanded="false"
																	aria-controls="ekit-submenu-823">Tattoo Styles<i
																		aria-hidden="true"
																		class="icon icon-down-arrow1 elementskit-submenu-indicator"></i></a>
																<ul class="elementskit-dropdown elementskit-submenu-panel"
																	id="ekit-submenu-823">
																	<li id="menu-item-826"
																		class="menu-item menu-item-type-post_type menu-item-object-page menu-item-826 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.tattoo-styles.japanese-tattoos') ? ' current-menu-item current_page_item active' : '' }}"
																		data-vertical-menu=750px><a
																			href="{{ route('page.tattoo-styles.japanese-tattoos') }}"
																			class=" dropdown-item{{ request()->routeIs('page.tattoo-styles.japanese-tattoos') ? ' active' : '' }}">Japanese
																			Tattoos</a>
																	<li id="menu-item-827"
																		class="menu-item menu-item-type-post_type menu-item-object-page menu-item-827 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.tattoo-styles.realism-tattoos') ? ' current-menu-item current_page_item active' : '' }}"
																		data-vertical-menu=750px><a
																			href="{{ route('page.tattoo-styles.realism-tattoos') }}"
																			class=" dropdown-item{{ request()->routeIs('page.tattoo-styles.realism-tattoos') ? ' active' : '' }}">Realism
																			Tattoos</a>
																	<li id="menu-item-825"
																		class="menu-item menu-item-type-post_type menu-item-object-page menu-item-825 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.tattoo-styles.tribal-tattoos') ? ' current-menu-item current_page_item active' : '' }}"
																		data-vertical-menu=750px><a
																			href="{{ route('page.tattoo-styles.tribal-tattoos') }}"
																			class=" dropdown-item{{ request()->routeIs('page.tattoo-styles.tribal-tattoos') ? ' active' : '' }}">Tribal
																			Tattoos</a>
																	<li id="menu-item-824"
																		class="menu-item menu-item-type-post_type menu-item-object-page menu-item-824 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.tattoo-styles.cartoon-tattoos') ? ' current-menu-item current_page_item active' : '' }}"
																		data-vertical-menu=750px><a
																			href="{{ route('page.tattoo-styles.cartoon-tattoos') }}"
																			class=" dropdown-item{{ request()->routeIs('page.tattoo-styles.cartoon-tattoos') ? ' active' : '' }}">Cartoon
																			Tattoos</a>
																</ul>
															</li>
															<li id="menu-item-219"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-219 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.piercing') ? ' current-menu-item current_page_item active' : '' }}"
																data-vertical-menu=750px><a
																	href="{{ route('page.gallery') }}"
																	class="ekit-menu-nav-link{{ request()->routeIs('page.gallery') ? ' active' : '' }}">Gallery</a>
															</li>
															<li id="menu-item-227"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-227 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.eyebrows-tattoo') ? ' current-menu-item current_page_item active' : '' }}"
																data-vertical-menu=750px><a
																	href="{{ route('page.eyebrows-tattoo') }}"
																	class="ekit-menu-nav-link{{ request()->routeIs('page.eyebrows-tattoo') ? ' active' : '' }}">Artists</a></li>
															<li id="menu-item-71"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-71 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.exhibition') ? ' current-menu-item current_page_item active' : '' }}"
																data-vertical-menu=750px><a
																	href="{{ route('page.exhibition') }}"
																	class="ekit-menu-nav-link{{ request()->routeIs('page.exhibition') ? ' active' : '' }}">FAQs</a>
															</li>
															<li id="menu-item-572"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-572 nav-item elementskit-mobile-builder-content"
																data-vertical-menu=750px><a
																	href="#"
																	class="ekit-menu-nav-link">Blog</a></li>
															<li id="menu-item-86"
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-86 nav-item elementskit-mobile-builder-content{{ request()->routeIs('page.contact-us') ? ' current-menu-item current_page_item active' : '' }}"
																data-vertical-menu=750px><a
																	href="{{ route('page.contact-us') }}"
																	class="ekit-menu-nav-link{{ request()->routeIs('page.contact-us') ? ' active' : '' }}">Contact
																	Us</a></li>
@include('partials.lang-switcher')

														</ul>
														<div class="elementskit-nav-identity-panel"><a
																class="elementskit-nav-logo"
																href="{{ route('page.home') }}" target="" rel=""><img
																	src="{{ asset('assets/imgs/logo.png') }}"
																	title="logo-crimson-ink-tattoo-studio.png"
																	alt="CrimsonInk Tattoo Studio"
																	decoding="async" /></a><button
																class="elementskit-menu-close elementskit-menu-toggler"
																type="button">X</button></div>
													</div>
													<div
														class="elementskit-menu-overlay elementskit-menu-offcanvas-elements elementskit-menu-toggler ekit-nav-menu--overlay">
													</div>
												</nav>
											</div>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
				</div>
			</div>
		</section>
	</div>
</header>