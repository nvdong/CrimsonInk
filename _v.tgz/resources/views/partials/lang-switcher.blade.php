{{-- Bộ chọn ngôn ngữ (lá cờ) cạnh Contact Us trên menu.
     Danh sách ngôn ngữ lấy từ config/locales.php. --}}
<li class="ci-lang nav-item elementskit-mobile-builder-content">
    @foreach (config('locales', []) as $code => $lang)
        <a class="ci-lang__item{{ app()->getLocale() === $code ? ' is-active' : '' }}"
           href="{{ route('locale.switch', $code) }}"
           hreflang="{{ $code }}"
           title="{{ $lang['label'] }}"
           aria-label="{{ $lang['label'] }}"
           @if (app()->getLocale() === $code) aria-current="true" @endif>
            <img src="{{ asset('assets/imgs/'.$lang['flag']) }}" alt="{{ $lang['label'] }}" height="18" decoding="async">
        </a>
    @endforeach
</li>
