<?php

/*
|--------------------------------------------------------------------------
| Danh sách artist
|--------------------------------------------------------------------------
| Nguồn dữ liệu duy nhất cho section "Professional Tattoo Artists" ở trang chủ,
| trang /artists và trang chi tiết /artists/{slug}.
|
| Trang chủ hiển thị tối đa 'home_limit' người, dư ra thì hiện nút "View all".
|
| CHÚ Ý: tên, mô tả và ảnh bên dưới đang là PLACEHOLDER lấy tạm từ thư viện ảnh
| của site gốc — thay bằng thông tin và ảnh thật của artist Crimson Ink trước khi
| đưa site lên production.
*/

return [

    'home_limit' => 2,

    'list' => [
        [
            'slug'  => 'artist-1',
            'name'  => 'Tên artist 1',
            'role'  => 'Fineline & Blackwork',
            'image' => 'tattoo-artist-1.jpg',
            'bio'   => 'Mô tả ngắn về artist: phong cách sở trường, số năm kinh nghiệm, điều khiến khách quay lại. Khoảng 2-3 dòng là vừa đẹp với bố cục này.',
        ],
        [
            'slug'  => 'artist-2',
            'name'  => 'Tên artist 2',
            'role'  => 'Realism & Portrait',
            'image' => 'tattoo-artist-2.jpg',
            'bio'   => 'Mô tả ngắn về artist: phong cách sở trường, số năm kinh nghiệm, điều khiến khách quay lại. Khoảng 2-3 dòng là vừa đẹp với bố cục này.',
        ],
        [
            'slug'  => 'artist-3',
            'name'  => 'Tên artist 3',
            'role'  => 'Japanese & Traditional',
            'image' => 'tattoo-artist-3.jpg',
            'bio'   => 'Mô tả ngắn về artist: phong cách sở trường, số năm kinh nghiệm, điều khiến khách quay lại. Khoảng 2-3 dòng là vừa đẹp với bố cục này.',
        ],
        [
            'slug'  => 'artist-4',
            'name'  => 'Tên artist 4',
            'role'  => 'Dotwork & Ornamental',
            'image' => 'junk-juz-tattoo-artist-bali.jpg',
            'bio'   => 'Mô tả ngắn về artist: phong cách sở trường, số năm kinh nghiệm, điều khiến khách quay lại. Khoảng 2-3 dòng là vừa đẹp với bố cục này.',
        ],
        [
            'slug'  => 'artist-5',
            'name'  => 'Tên artist 5',
            'role'  => 'Lettering & Script',
            'image' => 'mr-dolphin-tattoo-welcome-1.jpg',
            'bio'   => 'Mô tả ngắn về artist: phong cách sở trường, số năm kinh nghiệm, điều khiến khách quay lại. Khoảng 2-3 dòng là vừa đẹp với bố cục này.',
        ],
    ],
];
