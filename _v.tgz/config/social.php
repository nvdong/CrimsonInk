<?php

/*
|--------------------------------------------------------------------------
| Liên kết mạng xã hội
|--------------------------------------------------------------------------
| Dùng cho thanh social neo ở góc dưới bên phải (partials/social-dock).
| Đặt link nào là null / bỏ khỏi mảng thì mục đó không hiện.
|
| TODO: thay 2 link Instagram và Facebook bằng trang thật của Crimson Ink.
*/

return [
    'whatsapp'  => 'https://wa.me/84346955898',
    'instagram' => 'https://www.instagram.com/',
    'facebook'  => 'https://www.facebook.com/',
];
