<?php

/*
|--------------------------------------------------------------------------
| Ngôn ngữ hiển thị trên site
|--------------------------------------------------------------------------
| Dùng cho bộ chọn ngôn ngữ (lá cờ) trên menu. Thứ tự trong mảng chính là thứ
| tự lá cờ hiển thị. 'flag' là tên file trong public/assets/imgs.
|
| Thêm ngôn ngữ mới = thêm một dòng ở đây + tạo thư mục resources/lang/<mã>.
*/

return [
    'vi' => ['label' => 'Tiếng Việt', 'flag' => 'vnflat.png'],
    'en' => ['label' => 'English',    'flag' => 'ukflat.png'],
];
